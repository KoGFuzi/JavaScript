<?php
session_start();
$students = [
    ["username" => "student1", "password" => "student1", "role" => "student"],
    ["username" => "student2", "password" => "student2", "role" => "student"]
];

// 获取表单提交的用户名和密码
$username = $_POST['username'];
$password = $_POST['password'];

// 简单的用户名重复检查
foreach ($students as $student) {
    if ($student['username'] === $username) {
        echo "用户名已存在";
        exit();
    }
}

// 将新用户添加到数组中（此处仅为演示，实际使用应存储在数据库中）
$students[] = ["username" => $username, "password" => $password, "role" => "student"];
echo "注册成功";
