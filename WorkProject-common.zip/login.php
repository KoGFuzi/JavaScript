<?php
session_start();

$admin_username = "admin";
$admin_password = "admin";
$students = [
    ["username" => "student1", "password" => "student1", "role" => "student"],
    ["username" => "student2", "password" => "student2", "role" => "student"]
];

// 获取表单提交的用户名和密码
$username = $_POST['username'];
$password = $_POST['password'];

// 检查管理员登录
if ($username === $admin_username && $password === $admin_password) {
    $_SESSION['role'] = 'admin';
    header("Location: admin_page.html");
    exit();
}

// 检查学生登录
foreach ($students as $student) {
    if ($student['username'] === $username && $student['password'] === $password) {
        $_SESSION['role'] = 'student';
        header("Location: student_page.html");
        exit();
    }
}

echo "用户名或密码错误";

